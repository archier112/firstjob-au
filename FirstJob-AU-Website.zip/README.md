# FirstJob AU
Mobile-first static website for GitHub Pages.

## Publish
1. Create a public GitHub repository named `firstjob-au`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. In Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
4. GitHub will provide the public Pages address.

## Important
The included job posting form is a front-end demo and stores jobs only in the visitor's browser. A real public employer system needs a backend/database and authentication before launch.
